from django.shortcuts import redirect, render,HttpResponse
from numpy import average
from .models import User,UserActivity,UserFiles
from django.contrib import messages
from pandas import read_excel
from datetime import datetime
from django.contrib import auth
from django.contrib.auth.decorators import login_required
from django.core.files.storage import FileSystemStorage
import os
import json 
# Create your views here.

def home(request):
    if request.session.get('user'): return redirect('profile')
    return render(request, 'cargapp/base.html', {})

def loginpage(request):
    if request.user.is_authenticated: return redirect('profile')
    if request.method=='POST':
        sid=request.POST.get('SID')
        pword=request.POST.get('password')
        user=auth.authenticate(request,username=sid,password=pword)
        if user is not None:
            auth.login(request, user)
            intime=datetime.now()
            request.session['user']=sid
            user=User.objects.get(SID=sid)
            request.session['type']=user.type
            try:
                record=UserActivity.objects.get(SID=sid)
                record=UserActivity.objects.get(id=record.id)
                record.lastlogin=intime
                record.lastlogout=intime
                record.count+=1
            except:
                record=UserActivity(SID=user.SID,fullname=user.fullname,lastlogin=intime,lastlogout=intime,count=1)
            record.save()
            if pword=='welcome123#': 
                    messages.warning(request,"please change your password according to password instructions ")
                    return redirect('changepassword')
            messages.success(request,('You are logged in'))
            return redirect('profile')
        else:
            messages.error(request,('Error logging in'))
        return redirect('loginpage')
    if request.user.is_authenticated: return redirect('profile')
    return render(request,"cargapp/loginpage.html")

@login_required(login_url='loginpage')
def profile(request):
    sid=request.session.get('user')
    user=User.objects.get(SID=sid)
    return render(request,'cargapp/'+user.type+'.html',{'files': files})

@login_required(login_url='loginpage')
def logout(request):
    outime=datetime.now()
    sid=request.session.get('user')
    record=UserActivity.objects.get(SID=sid)
    record=UserActivity.objects.get(id=record.id)
    record.lastlogout=outime
    record.save()
    messages.info(request,('you are logged out'))
    del request.session['user']; del request.session['type']
    auth.logout(request)
    return redirect('home')


def register(request):
    if request.method=='POST':
        sid=request.POST.get('SID')
        fname=request.POST.get('fullname')
        email=request.POST.get('email')
        type1=request.POST.get('type')
        pword=request.POST.get('password')
        cpword=request.POST.get('confirm password')
        if len(pword)>7 and pword==cpword and set(pword)-{1,2,3,4,5,6,7,8,9,0}!={} and pword!='welcome123#':
            try:
                User.objects.get(SID=sid)
                messages.info(request,('user already exits'))
            except:
                User(SID=sid,fullname=fname,email=email,password=pword,type=type1).save()
                auth.models.User.objects.create_user(username=sid,password=pword).save()
                messages.success(request, ('You are now registered'))
            return redirect('loginpage')
        messages.error(request,('please follow the necessary conditions to become a valid user '))
        return redirect('register')
    return render(request,'cargapp/register.html')

@login_required(login_url='loginpage')
def bulkregister(request):
    if request.method=='POST':
        excelfile=request.FILES.get('file')
        if not excelfile.name.endswith('xlsx'):
            messages.info(request,'wrong format')
            return render(request,'cargapp/register.html')
        data=read_excel(excelfile)#dataframe
        data=data.values.tolist()#to convert dataframe to list
        for person in data:
            try:
                auth.models.User.objects.get(username=person[0])
            except:
                auth.models.User.objects.create_user(username=person[0],password=person[3]).save()
            try: 
                User.objects.get(SID=person[0])
            except:
                User(SID=person[0],fullname=person[1],email=person[2],password=person[3],type=person[4]).save()
        messages.success(request,'regsitrations are completed successfully')
        return redirect('profile')
    return render(request,'cargapp/bulkregister.html')

@login_required(login_url='loginpage')
def changepassword(request):
    if request.method=='POST':
        sid=request.session.get('user')
        opword=request.POST.get('old password')
        pword=request.POST.get('password')
        cpword=request.POST.get('confirm password')
        if request.user.is_authenticated:
            user=request.session.get('user')
            try:
                user=User.objects.get(SID=sid)
                opword1=user.password
                if opword!=opword1:
                    messages.error(request,"your old password is not matching")
                    return redirect("changepassword")
            except:
                pass
            if len(pword)>7 and pword==cpword and set(pword)-{1,2,3,4,5,6,7,8,9,0}!={} and pword!='welcome123#':
                user=request.user
                request.user.set_password(pword)
                request.user.save()
                auth.update_session_auth_hash(request,user)
                user=User.objects.get(SID=request.user.username)
                user.password=pword
                user.save()
                messages.success(request, ('your password is changed successfully please login again for security reasons'))
                return redirect('logout')
            messages.error(request,('please keep a password that matches the instructions given below'))
            return redirect('changepassword')
    return render(request,'cargapp/changepassword.html')

@login_required(login_url='loginpage')
def editprofile(request):
    return redirect('changepassword')

@login_required(login_url='loginpage')
def studentresults(request):
    return render(request,'cargapp/studentresults.html')

@login_required(login_url='loginpage')
def fcarresults(request):
    if request.method == 'POST':
        file=request.FILES['file']
        regulation=request.POST.get('regulation')
        year=request.POST.get('year')
        department=request.POST.get('department')
        course=request.POST.get('course')
        semester=request.POST.get('semester')
        if UserFiles.objects.filter(SID=request.user.username,regulation=regulation,year=year,department=department,course=course,semester=semester,file=file.name).exists():
            record=UserFiles.objects.get(SID=request.user.username,regulation=regulation,year=year,department=department,course=course,semester=semester,file=file.name)
            request.session['file']=file
            fileupdate(request,record.id)
        else:
            p='%s/%s/%s/%s/%s/%s/'%(request.user.username,regulation,year,course,department,semester)
            fs=FileSystemStorage()
            fs.save(p+file.name,file)
            record=UserFiles(SID=request.user.username,regulation=regulation,year=year,department=department,course=course,semester=semester,file=file.name)
            record.save()
        df=read_excel(file)
        df=df.values.tolist()
        rows=len(df)
        cols=len(df[0])
        dp=[0 for _ in range(cols)]
        for i in range(3,rows):
            for j in range(1,cols):
                dp[j]+=df[i][j]
        cos={}
        for j in range(1,cols):
            co=df[2][j]
            if cos.get(co): 
                cos[co][0]+=1
                cos[co][1]+=dp[j]
                cos[co][2]+=df[1][j]
            else: 
                cos[co]=[1,dp[j],df[1][j]]
        for co in cos:
            c=cos[co][0]
            marks=cos[co][1]
            cos[co].append(marks/((rows-3)))
            cos[co].append(cos[co][-1]/cos[co][-2]*100)
        values=[['COS','Max_Marks','Average','Average %']]
        ave_perce_marks=[]
        for co in cos:
            c,total,max_marks,average,ave_perce=cos[co]
            ave_perce_marks.append(ave_perce)
            values.append([co,max_marks,average,ave_perce])
        request.session['values']=values
        cos=list(cos.keys())
        request.session['cos']=cos
        request.session['marks']=ave_perce_marks
        return graphresults(request,record.id)
    return render(request,'cargapp/fcarresults.html')

def graphresults(request,pk):
    record=UserFiles.objects.get(id=pk)
    values=request.session['values']
    cos=json.dumps(request.session['cos'])
    marks=json.dumps(request.session['marks'])
    del request.session['values']
    del request.session['cos']
    del request.session['marks']
    print(cos,marks)
    return render(request,'cargapp/graphresults.html',{'record':record,'values':values,'cos':cos,'marks':marks})

def files(request):
    files=set()
    if UserFiles.objects.filter(SID=request.user.username).exists:
        records=UserFiles.objects.filter(SID=request.user.username)
        for record in records:
            p='/media/%s/%s/%s/%s/%s/%s/'%(record.SID,record.regulation,record.year,record.course,record.department,record.semester)
            files.add((record,p+record.file))
    return render(request,'cargapp/files.html',{'files': files})


def filedelete(request,pk):
    record=UserFiles.objects.get(id=pk)
    p='\\media\\%s\\%s\\%s\\%s\\%s\\%s\\'%(record.SID,record.regulation,record.year,record.course,record.department,record.semester)
    os.remove('C:\python\PycharmProjects\djangoprojects\projectcarg'+p+record.file)
    record.delete()
    return redirect('files')

def fileupdate(request,pk):
    record=UserFiles.objects.get(id=pk)
    p='\\media\\%s\\%s\\%s\\%s\\%s\\%s\\'%(record.SID,record.regulation,record.year,record.course,record.department,record.semester)
    os.remove('C:\python\PycharmProjects\djangoprojects\projectcarg'+p+record.file)
    p='%s/%s/%s/%s/%s/%s/'%(request.user.username,record.regulation,record.year,record.course,record.department,record.semester)
    file=request.session['file']
    del request.session['file']
    fs=FileSystemStorage()
    fs.save(p+file.name,file)


