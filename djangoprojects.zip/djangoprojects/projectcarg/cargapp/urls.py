from django.contrib import admin
from django.urls import path
from . import views
urlpatterns = [
    path('', views.home,name='home'),
    path('loginpage',views.loginpage,name='loginpage'),
    path('profile',views.profile,name='profile'),
    path('editprofile',views.editprofile,name='editprofile'),
    path('register',views.register,name='register'),
    path('changepassword',views.changepassword,name='changepassword'),
    path('logout',views.logout,name='logout'),
    path('bulkregister',views.bulkregister,name='bulkregister'),
    path('fcarresults',views.fcarresults,name='fcarresults'),
    path('graphresults/<int:pk>',views.graphresults,name='graphresults'),
    path('studentresults',views.studentresults,name='studentresults'),
    path('files',views.files,name='files'),
    path('filedelete/<int:pk>',views.filedelete,name='filedelete'),
    path('fileupdate/<int:pk>',views.fileupdate,name='fileupdate'),
]