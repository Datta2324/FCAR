from django.apps import AppConfig


class CargappConfig(AppConfig):
    name = 'cargapp'
